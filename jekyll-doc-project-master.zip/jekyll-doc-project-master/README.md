## Jekyll Doc Project -- a theme for building documentation websites with Jekyll

This repo contains the Jekyll Doc Project theme, which is used for creating documentation projects with Jekyll. For information on getting started, see \_docs/jekyllhowto/Theme Instructions/jekyllhow-to-getting-started.md. The Theme Instructions folder contains all the documentation needed to work with this theme.
