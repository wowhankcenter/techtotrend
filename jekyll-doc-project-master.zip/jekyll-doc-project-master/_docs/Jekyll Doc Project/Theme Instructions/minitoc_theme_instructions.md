---
title: Get Started
permalink: /minitoc_theme_instructions.html
sidebar: jekyllhowto
---

{% include pdfminitoc.html %}
